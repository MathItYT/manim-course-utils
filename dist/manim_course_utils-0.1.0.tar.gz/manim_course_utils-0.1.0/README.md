# Utilidades del curso de Manim

Utilidades del curso de [ManimCE](https://www.manim.community) disponible en el canal [https://youtube.com/@mathlike].
