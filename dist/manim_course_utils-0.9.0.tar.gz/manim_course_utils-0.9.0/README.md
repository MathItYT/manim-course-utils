# Utilidades del curso de Manim

Utilidades del curso de [ManimCE](https://www.manim.community) disponible en el canal de [MathLike](https://youtube.com/@mathlike).
